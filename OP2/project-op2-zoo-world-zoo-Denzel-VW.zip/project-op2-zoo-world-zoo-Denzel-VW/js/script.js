/* schrijf al je javascript code hier */



function spelUitleg() {
    var x = document.getElementById("uitleg");
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
  }

var dieren= ['leeuw','olifant','giraffe','aap','tijger','slang']

function genDier() {
    x = Math.floor(Math.random()*6);
    document.getElementById("kiesdier").innerHTML = dieren[x];
}

var kleur="red";

function colorCell(locatie) {
    document.getElementsByClassName("vak")[locatie].style.backgroundColor = kleur ;
}
function getcolor(which) {
    kleur = which ;
    document.getElementById().style.backgroundColor = kleur ;
}

function reset() {
    location.reload();
}

var totaal;
var totaalFix;
var showPrice;

function showPrice(prijs) {
    document.getElementById("table1").innerHTML = "<th>Aantal</th><th>Prijs</th>";
    if (prijs == 7.60) {
        for (i = 0; i <= 10; i++) {
            totaal = prijs * i;
            totaalFix = totaal.toFixed(2);
            document.getElementById("table1").innerHTML += '<tr><td>' + i + '</td><td>€' + totaalFix + '</td></tr>';
        }
    }
    else if (prijs == 16.50) {
        for (i = 0; i <= 10; i++) {
            totaal = prijs * i;
            document.getElementById("table1").innerHTML += '<tr><td>' + i + '</td><td>€' + totaal + '</td></tr>';
        }
    }
    else if (prijs == 50) {
        for (i = 0; i <= 10; i++) {
            totaal = prijs * i;
            document.getElementById("table1").innerHTML += '<tr><td>' + i + '</td><td>€' + totaal + '</td></tr>';
        }
    }
}